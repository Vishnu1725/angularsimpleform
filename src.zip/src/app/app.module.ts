import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { FormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';

import { AppComponent } from './app.component';
import { HomepageComponent } from './homepage/homepage.component';
import { RegisterComponent } from './register/register.component';
import { RouterModule, Routes } from '@angular/router';
//import { routes } from './app.routing';
const routes: Routes = [
  { path: 'first-component', component: HomepageComponent },
  { path: 'second-component', component: RegisterComponent },
]; 
@NgModule({
  declarations: [
    AppComponent,
    HomepageComponent,
    RegisterComponent
  ],
  imports: [
    FormsModule,
    BrowserModule,RouterModule.forRoot(routes),HttpClientModule
    
  ],
  
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
